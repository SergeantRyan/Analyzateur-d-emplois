Il faut installer les modules dans le fichier requirements.txt
Cela assure le bon fonctionnement du programme.